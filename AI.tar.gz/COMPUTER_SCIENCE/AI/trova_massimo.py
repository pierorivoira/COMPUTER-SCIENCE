from tkinter.simpledialog import askinteger, askfloat
DIMENSIONE = askinteger('Entry', 'Inserisci il numero delle osservazioni')
print(DIMENSIONE)
DATI = []
for i in range(DIMENSIONE):
	dato = askfloat('Entry', 'Inserisci i dati uno alla volta')
	print(dato)
	DATI.append(dato)
print(DATI)
def maxarray(lista):
	M = lista[0]
	for i in lista:
		if i > M:
			M = i
	return M
t = maxarray(DATI)
print('Il valore massimo è %f' % t)
