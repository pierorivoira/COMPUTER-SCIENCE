import os
import pandas as pd
from tkinter.simpledialog import askstring
user = os.getlogin()
os.chdir('/home/%s/COMPUTER_SCIENCE/AI/DATA' % user)
file_name = askstring('Entry', 'Inserisci il nome del file csv con i dati (senza estensione)')
print('Your dataframe will be named <df>')
df = pd.read_csv('%s.csv' % file_name)
print(df.info())
column_name = askstring('Entry', 'Inserisci il nome della colonna che ti interessa') 
DATA = df['%s' % column_name]
def maxarray(lista):
	M = lista[0]
	for i in lista:
		if i > M:
			M = i
	return M
t = maxarray(DATA)
print('Il valore massimo è %f' % t)
