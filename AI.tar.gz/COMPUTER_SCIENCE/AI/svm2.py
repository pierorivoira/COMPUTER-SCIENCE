# svm2.py

import os
# os.system('sudo apt-get install python3-sklearn python3-sklearn-lib python-sklearn-doc')
import pandas as pd
from sklearn import svm, datasets
os.system('wget wget https://raw.githubusercontent.com/pierorivoira/COMPUTER-SCIENCE/refs/heads/main/iris.csv')
iris_df = pd.read_csv('iris.csv')
print(iris_df)

