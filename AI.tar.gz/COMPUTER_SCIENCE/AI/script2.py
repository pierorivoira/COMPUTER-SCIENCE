l = '*\t *'
print('*' * 10)
print(l)
print('*' * 10)
