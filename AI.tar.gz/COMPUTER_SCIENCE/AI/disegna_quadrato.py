f = '*\t\t  *\n*\t\t  *\n*\t\t  *\n*            \t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *'
print('* ' * 10)
print(f)
print('* ' * 10)
