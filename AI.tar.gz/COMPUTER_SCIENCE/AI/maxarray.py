def maxarray(lista):
	M = lista[0]
	for i in lista:
		if i < M:
			print('Error!')
		else:
			M = i
	return M

data = [0,1,2,3,4,5]
t = maxarray(data)
print(t)
