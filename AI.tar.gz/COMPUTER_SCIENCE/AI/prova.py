import os
import pandas as pd
from tkinter.simpledialog import askstring
user = os.getlogin()
os.chdir('/home/%s/COMPUTER_SCIENCE/AI/DATA' % user)
file_name = askstring('Entry', 'Inserisci il nome del file csv con i dati')
basal_metabolic_rate = pd.read_csv('%s' % file_name)
print(basal_metabolic_rate.info())
column_name = askstring('Entry', 'Inserisci il nome della colonna che ti interessa') 

for i in range('%s' % file_name['%s' % column_name].count()):
	print(i)
