from tkinter.simpledialog import askstring
#global gruppo
gruppo = askstring('Entry', 'Scegli il GRUPPO di bovine (<F> per freschissime, <f> per fresche, <s> per stanche)')
if gruppo == 'F' or gruppo == 'f' or gruppo == 's':
	print('GRUPPO di bovine <%s> inserito con SUCCESSO!' % gruppo)
	print('')
else:
	print('ERRORE: prova a reinserire il gruppo!')
if gruppo == 'F':
	print('La RAZIONE sarà calcolata per il GRUPPO <freschissime>!')
	print('(1^-9^ settimana di lattazione)')
	print('')
	print('<SETTIMANA DI GRAVIDANZA> impostata a 0 (zero)')
elif gruppo == 'f':
	print('La RAZIONE sarà calcolata per il GRUPPO <fresche>!')
	print('(10^-20^ settimana di lattazione)')
	print('')
elif gruppo == 's':
	print('La RAZIONE sarà calcolata per il GRUPPO <stanche>!')
	print('(dalla 21^ settimana di lattazione)')
	print('')
