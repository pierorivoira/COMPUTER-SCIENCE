# A first Python script
# script1.py

import os, sys

print(os.getlogin())
print(sys.platform)
print(2**100)
x = 'Python è una figata!'
print(x * 8)
