# script3.py
l = '*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *\n*\t\t  *'
print('* ' * 10)
print(l)
print('* ' * 10)
print(l)
print('* ' * 10)
