from tkinter.simpledialog import askinteger
n = askinteger('Entry', 'Inserisci il numero di termini da sommare')
N = n + 1
print('Il programma restituisce il Triangolo di Tartaglia formata da %d righe' % N)
triangolo = []
sequenza_iniziale = [1,2,1]
unità = 1

print('[1, 2, 1]')

for j in range(n):
    sequenza_nuova = [1]
    for i in range(len(sequenza_iniziale)-1):
        sequenza_nuova.append(sequenza_iniziale[i]+sequenza_iniziale[i+1])  
    sequenza_nuova.append(unità)
    sequenza_iniziale = sequenza_nuova
    print(sequenza_nuova)
